<?php require_once('header.php'); ?>

<?php
// Initialize messages
$error_message = '';
$success_message = '';

// Check if email and token are present in the URL
if (!isset($_GET['email']) || !isset($_GET['token'])) {
    $error_message = '<p style="color:red;">Invalid verification link.</p>';
    header('location: ' . BASE_URL);
    exit;
}

// Sanitize the email (basic sanitization to prevent injection in display)
$email = filter_var($_GET['email'], FILTER_SANITIZE_EMAIL);
$token = $_GET['token'];

// Check if the email exists and the token matches
$statement = $pdo->prepare("SELECT * FROM tbl_customer WHERE cust_email=?");
$statement->execute(array($email));
$result = $statement->fetchAll(PDO::FETCH_ASSOC);

if (count($result) === 0) {
    $error_message = '<p style="color:red;">Email not found.</p>';
    header('location: ' . BASE_URL);
    exit;
}

$token_valid = false;
foreach ($result as $row) {
    if ($token === $row['cust_token']) {
        $token_valid = true;
        break;
    }
}

if (!$token_valid) {
    $error_message = '<p style="color:red;">Invalid token.</p>';
    header('location: ' . BASE_URL);
    exit;
}

// If we reach this point, the token is valid. Activate the user.
$statement = $pdo->prepare("UPDATE tbl_customer SET cust_token=?, cust_status=? WHERE cust_email=?");
$statement->execute(array('', 1, $email));

$success_message = '<p style="color:green;">Your email is verified successfully. You can now login to our website.</p><p><a href="' . BASE_URL . 'login.php" style="color:#167ac6;font-weight:bold;">Click here to login</a></p>';
?>

<div class="page-banner" style="background-color:#444;">
    <div class="inner">
        <h1>Email Verification</h1>
    </div>
</div>

<div class="page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="user-content">
                    <?php 
                    if ($error_message != '') {
                        echo $error_message;
                    }
                    if ($success_message != '') {
                        echo $success_message;
                    }
                    ?>
                </div>                
            </div>
        </div>
    </div>
</div>

<?php require_once('footer.php'); ?>