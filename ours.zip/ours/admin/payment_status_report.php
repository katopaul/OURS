<?php
// Database Connection
$conn = new mysqli("localhost", "root", "", "ecommerceweb");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function generatePaymentStatusReport($conn) {
    $sql = "SELECT p.payment_id, p.payment_date, 
                   p.payment_method, p.payment_status, p.shipping_status
            FROM tbl_payment p
            ORDER BY p.payment_date DESC";
    $result = $conn->query($sql);

    if (!$result) {
        die("Query failed: " . $conn->error);
    }

    $output = "<h2>Payment Status Report</h2>
               <table class='report-table' border='1' cellpadding='5' cellspacing='0'>
               <thead>
                   <tr>
                       <th>Payment ID</th>
                       <th>Payment Date</th>
                       <th>Method</th>
                       <th>Payment Status</th>
                       <th>Shipping Status</th>
                   </tr>
               </thead><tbody>";

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $output .= "<tr>
                           <td>{$row['payment_id']}</td>
                           <td>{$row['payment_date']}</td>
                           <td>{$row['payment_method']}</td>
                           <td>{$row['payment_status']}</td>
                           <td>{$row['shipping_status']}</td>
                       </tr>";
        }
    } else {
        $output .= "<tr><td colspan='5'>No records found</td></tr>";
    }

    $output .= "</tbody></table>";
    return $output;
}

function exportToPDF($htmlContent, $filename) {
    require_once('tcpdf/tcpdf.php');
    $pdf = new TCPDF();
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor('Ecommerce Web');
    $pdf->SetTitle('Payment Status Report');
    $pdf->SetMargins(10, 10, 10);
    $pdf->AddPage();
    $pdf->writeHTML($htmlContent, true, false, true, false, '');
    $pdf->Output($filename, 'D');
}

// Handle PDF export before any output
if (isset($_GET['export']) && $_GET['export'] == 'pdf') {
    $css = "
        <style>
            h2 { font-family: Arial, sans-serif; color: #333; text-align: center; margin-bottom: 20px; }
            .report-table { width: 100%; border-collapse: collapse; font-family: Arial, sans-serif; }
            .report-table th, .report-table td { border: 1px solid #000; padding: 8px; text-align: left; }
            .report-table th { background-color: #2196F3; color: white; }
            .report-table tr:nth-child(even) { background-color: #f2f2f2; }
        </style>
    ";
    $htmlContent = $css . generatePaymentStatusReport($conn);
    exportToPDF($htmlContent, 'payment_status_report.pdf');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Status Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        h2 {
            color: #333;
            text-align: center;
        }
        .report-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .report-table th, .report-table td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }
        .report-table th {
            background-color: #2196F3;
            color: white;
        }
        .report-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .report-table tr:hover {
            background-color: #f1f1f1;
        }
        .controls {
            margin-bottom: 20px;
            text-align: center;
        }
        button {
            padding: 10px 20px;
            background-color: #2196F3;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #1976D2;
        }
    </style>
</head>
<body>
    <div class="controls">
        <button onclick="generatePDF()">Export to PDF</button>
    </div>
    <?php echo generatePaymentStatusReport($conn); ?>

    <script>
        function generatePDF() {
            window.location.href = "?export=pdf";
        }
    </script>
</body>
</html>
<?php $conn->close(); ?>