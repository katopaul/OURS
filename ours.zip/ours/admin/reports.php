<?php
// Database Connection
$conn = new mysqli("localhost", "root", "", "ecommerceweb");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reports Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        .dashboard {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            border-radius: 5px;
        }
        h1 {
            color: #333;
            text-align: center;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }
        select, input[type="date"], button {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .export-btn {
            background-color: #2196F3;
        }
        .export-btn:hover {
            background-color: #1976D2;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <h1>Reports Dashboard</h1>
        <form method="GET" action="">
            <div class="form-group">
                <label for="report">Select Report:</label>
                <select name="report" id="report">
                    <option value="order_summary">Order Summary</option>
                    <option value="payment_status">Payment Status</option>
                    <option value="product_sales">Product Sales</option>
                </select>
            </div>
            <div class="form-group">
                <label for="start_date">Start Date:</label>
                <input type="date" name="start_date" id="start_date">
            </div>
            <div class="form-group">
                <label for="end_date">End Date:</label>
                <input type="date" name="end_date" id="end_date">
            </div>
            <button type="submit">Generate Report</button>
            <button type="submit" name="export" value="pdf" class="export-btn">Export to PDF</button>
        </form>
    </div>

    <script>
        document.querySelector('form').addEventListener('submit', function(e) {
            const report = document.getElementById('report').value;
            if (!e.submitter.classList.contains('export-btn')) {
                e.preventDefault();
                window.location.href = `${report}_report.php?${new URLSearchParams(new FormData(this)).toString()}`;
            }
        });
    </script>

    <?php
    if (isset($_GET['report']) && isset($_GET['export']) && $_GET['export'] == 'pdf') {
        $reportType = $_GET['report'];
        $file = "{$reportType}_report.php";
        if (file_exists($file)) {
            header("Location: $file?" . http_build_query($_GET));
            exit;
        }
    }
    ?>
</body>
</html>
<?php $conn->close(); ?>