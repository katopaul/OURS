<?php
// Database Connection
$conn = new mysqli("localhost", "root", "", "ecommerceweb");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to generate the order summary report with date filtering
function generateOrderSummaryReport($conn, $startDate = null, $endDate = null) {
    $whereClause = "";
    if ($startDate && $endDate) {
        $whereClause = "WHERE p.payment_date BETWEEN '$startDate' AND '$endDate'";
    }

    $sql = "SELECT o.id, o.product_name, o.size, o.color, o.quantity, o.unit_price, 
                   (o.quantity * o.unit_price) AS total, p.payment_date, p.payment_status
            FROM tbl_order o
            JOIN tbl_payment p ON o.payment_id = p.payment_id
            $whereClause
            ORDER BY o.id DESC";

    $result = $conn->query($sql);

    if (!$result) {
        die("Query failed: " . $conn->error);
    }

    $output = "<h2>Ecommerce Order Summary Report</h2>
               <table class='report-table' border='1' cellpadding='5' cellspacing='0'>
               <thead>
                   <tr>
                       <th>Order ID</th>
                       <th>Product Name</th>
                       <th>Size</th>
                       <th>Color</th>
                       <th>Quantity</th>
                       <th>Unit Price</th>
                       <th>Total</th>
                       <th>Payment Date</th>
                       <th>Payment Status</th>
                   </tr>
               </thead><tbody>";

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $output .= "<tr>
                           <td>{$row['id']}</td>
                           <td>{$row['product_name']}</td>
                           <td>{$row['size']}</td>
                           <td>{$row['color']}</td>
                           <td>{$row['quantity']}</td>
                           <td>\${$row['unit_price']}</td>
                           <td>\${$row['total']}</td>
                           <td>{$row['payment_date']}</td>
                           <td>{$row['payment_status']}</td>
                       </tr>";
        }
    } else {
        $output .= "<tr><td colspan='9'>No records found</td></tr>";
    }

    $output .= "</tbody></table>";
    return $output;
}

// Handle PDF export
if (isset($_GET['export']) && $_GET['export'] == 'pdf') {
    require_once('tcpdf/tcpdf.php');
    
    $startDate = $_GET['start_date'] ?? null;
    $endDate = $_GET['end_date'] ?? null;
    $htmlContent = generateOrderSummaryReport($conn, $startDate, $endDate);
    
    $pdf = new TCPDF();
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor('Ecommerce Web');
    $pdf->SetTitle('Order Summary Report');
    $pdf->SetMargins(10, 10, 10);
    $pdf->AddPage();
    $pdf->writeHTML($htmlContent, true, false, true, false, '');
    $pdf->Output('order_summary_report.pdf', 'D');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Summary Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f4f4f4; }
        h2 { color: #333; text-align: center; }
        .report-table { width: 100%; border-collapse: collapse; background-color: #fff; }
        .report-table th, .report-table td { border: 1px solid #000; padding: 8px; text-align: left; }
        .report-table th { background-color: #4CAF50; color: white; }
        .report-table tr:nth-child(even) { background-color: #f9f9f9; }
        .filters { text-align: center; margin-bottom: 20px; }
        .filters input, .filters button { padding: 8px; margin: 5px; }
        button { background-color: #4CAF50; color: white; border: none; cursor: pointer; }
        button:hover { background-color: #45a049; }
    </style>
</head>
<body>
    <div class="filters">
        <form method="GET">
            <label for="start_date">Start Date:</label>
            <input type="date" id="start_date" name="start_date" required>
            <label for="end_date">End Date:</label>
            <input type="date" id="end_date" name="end_date" required>
            <button type="submit">Filter</button>
        </form>
        <button onclick="generatePDF()">Export to PDF</button>
    </div>
    <?php 
        $startDate = $_GET['start_date'] ?? null;
        $endDate = $_GET['end_date'] ?? null;
        echo generateOrderSummaryReport($conn, $startDate, $endDate); 
    ?>
    <script>
        function generatePDF() {
            const startDate = document.getElementById('start_date').value;
            const endDate = document.getElementById('end_date').value;
            if (startDate && endDate) {
                window.location.href = `?export=pdf&start_date=${startDate}&end_date=${endDate}`;
            } else {
                alert('Please select a date range before exporting.');
            }
        }
    </script>
</body>
</html>
<?php $conn->close(); ?>
