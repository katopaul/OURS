<?php
// Database Connection
$conn = new mysqli("localhost", "root", "", "ecommerceweb");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function generateProductSalesReport($conn) {
    $sql = "SELECT p.p_id, p.p_name, SUM(o.quantity) AS total_quantity, 
                   SUM(o.quantity * o.unit_price) AS total_revenue
            FROM tbl_product p
            JOIN tbl_order o ON p.p_id = o.product_id
            JOIN tbl_payment pay ON o.payment_id = pay.payment_id
            WHERE pay.payment_status = 'Completed'
            GROUP BY p.p_id, p.p_name
            ORDER BY total_revenue DESC";
    $result = $conn->query($sql);

    if (!$result) {
        die("Query failed: " . $conn->error);
    }

    $output = "<h2>Product Sales Report</h2>
               <table class='report-table' border='1' cellpadding='5' cellspacing='0'>
               <thead>
                   <tr>
                       <th>Product ID</th>
                       <th>Product Name</th>
                       <th>Total Quantity Sold</th>
                       <th>Total Revenue</th>
                   </tr>
               </thead><tbody>";

    $grand_total_revenue = 0; // Initialize grand total

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $output .= "<tr>
                           <td>{$row['p_id']}</td>
                           <td>{$row['p_name']}</td>
                           <td>{$row['total_quantity']}</td>
                           <td>\${$row['total_revenue']}</td>
                       </tr>";
            $grand_total_revenue += $row['total_revenue']; // Accumulate total revenue
        }
    } else {
        $output .= "<tr><td colspan='4'>No records found</td></tr>";
    }

    // Add footer row with grand total
    $output .= "<tfoot>
                    <tr style='font-weight: bold;'>
                        <td colspan='3'>Grand Total</td>
                        <td>\$$grand_total_revenue</td>
                    </tr>
                </tfoot>";

    $output .= "</tbody></table>";
    return $output;
}

function exportToPDF($htmlContent, $filename) {
    require_once('tcpdf/tcpdf.php');
    $pdf = new TCPDF();
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor('Ecommerce Web');
    $pdf->SetTitle('Product Sales Report');
    $pdf->SetMargins(10, 10, 10);
    $pdf->AddPage();
    $pdf->writeHTML($htmlContent, true, false, true, false, '');
    $pdf->Output($filename, 'D');
}

// Handle PDF export before any output
if (isset($_GET['export']) && $_GET['export'] == 'pdf') {
    $css = "
        <style>
            h2 { font-family: Arial, sans-serif; color: #333; text-align: center; margin-bottom: 20px; }
            .report-table { width: 100%; border-collapse: collapse; font-family: Arial, sans-serif; }
            .report-table th, .report-table td { border: 1px solid #000; padding: 8px; text-align: left; }
            .report-table th { background-color: #FF5722; color: white; }
            .report-table tr:nth-child(even) { background-color: #f2f2f2; }
            .report-table tfoot td { font-weight: bold; background-color: #ddd; }
        </style>
    ";
    $htmlContent = $css . generateProductSalesReport($conn);
    exportToPDF($htmlContent, 'product_sales_report.pdf');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Product Sales Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        h2 {
            color: #333;
            text-align: center;
        }
        .report-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .report-table th, .report-table td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }
        .report-table th {
            background-color: #FF5722;
            color: white;
        }
        .report-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .report-table tr:hover {
            background-color: #f1f1f1;
        }
        .report-table tfoot td {
            font-weight: bold;
            background-color: #ddd;
        }
        .controls {
            margin-bottom: 20px;
            text-align: center;
        }
        button {
            padding: 10px 20px;
            background-color: #FF5722;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #E64A19;
        }
    </style>
</head>
<body>
    <div class="controls">
        <button onclick="generatePDF()">Export to PDF</button>
    </div>
    <?php echo generateProductSalesReport($conn); ?>

    <script>
        function generatePDF() {
            window.location.href = "?export=pdf";
        }
    </script>
</body>
</html>
<?php $conn->close(); ?>